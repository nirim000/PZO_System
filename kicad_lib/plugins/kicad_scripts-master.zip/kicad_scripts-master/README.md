# kicad_scripts
Some kicad scripts

## Teardrops

This action plugin adds and deletes teardrops to a PCB.<br>
See the README file in the teardrops directory to get details about it.

This plugin now support Kicad V6 in the `master` branch.
For V5/V5.99 Kicad version, please use the `V5`branch.
